# import numpy as np
from lib import add

if __name__ == '__main__':
#     ZEROS = np.zeros(5)
    a = [1, 2, 3, 4, 5]
    print(a)
#     print(ZEROS)
    print(add(5,6))
    print(add(5,7))